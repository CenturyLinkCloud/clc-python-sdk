
ENDPOINT_URL_V1 = "https://api.ctl.io/REST/"
ENDPOINT_URL_V2 = "https://api.ctl.io"

