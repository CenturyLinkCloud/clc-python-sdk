
"""
Exception definitions.
"""


class xxxxxx(Exception):
	"""Error."""
	pass


